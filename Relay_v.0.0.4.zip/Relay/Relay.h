/**версия 0.0.4                     version 0.0.4
создал Александр Ющенко             created by Aleksandr Yuschenko
mailto: asyuschenko@gmail.com
web site: http://allforproject.ru
lib page: http://allforproject.ru/arduino-relay-lib-0-0-4/
2019.09.09
*/
#ifndef Relay_h
#define Relay_h

#include "Arduino.h"
#include "Timer.h"
class Relay {
public:

    Relay();
    Relay(uint8_t pin, uint8_t relayProgram);
    Relay(uint8_t pin, uint8_t relayProgram, uint32_t time);
    Relay(uint8_t pin, uint8_t relayProgram, uint32_t pattern, uint32_t interval);
    Relay(uint8_t pin, uint8_t relayProgram, uint32_t pattern, uint32_t interval, uint16_t frequency);

    enum relayState {ON, OFF, ON_TIME, ON_TIME_END, OFF_TIME, OFF_TIME_END, BLINK, BUZZER};

    void start();                                 /*Запускает программу реле. Для остановки выполнения программ 4 и 5 испльзуется метод stop()*/
    void stop();                                  /*Останавливает любую запущенную программу реле и устанавливает реле в исходное состояние*/
    void loop();                                  /*Данный метод должен крутиться в цикле loop{} скетча*/

/*setters-getters*/
    void setPin(uint8_t pin);                     /*Устанавливает пин управления реле*/
    void setTime(uint32_t time);                  /*Устанавливает время управления реле для программ 1 и 3*/
    void setPattern(uint32_t pattern);            /*Устанавливает маску мигания для программ 4 и 5*/
    void setInterval(uint32_t interval);          /*Устанавливает время длительности 1 импульса в маске мигания для программ 4 и 5*/
    void setFrequency (uint16_t frequency);       /*Устанавливает частоту сигнала для программы 5*/
    void setRelayProgram (uint8_t relayProgram);  /*Устанавливает тип программы управления реле*/

    relayState getState();                        /*Возвращает состояние реле, см. relayState*/

private:

    uint8_t _relayProgram;
    /** [relayProgram]
    * 0 - выключить реле
    * 1 - выключить реле на время, затем включить
    * 2 - включить реле
    * 3 - включить реле на время, затем выключить
    * 4 - мигать по маске
    * 5 - пищать по маске
    * 6 - переключить реле
    */
    bool _exec = false;
    uint8_t _pin;
    relayState state;

/*for Timer*/
    uint32_t _time = 0;
    Timer timer;
    uint8_t time_delay(uint32_t time);

/*advanced methods*/
    void on();
    void off();
    void onTime();
    void offTime();
    void blink();
    void buzzer();
    void toggle();
    void setup();

/*basic methods*/
    void setHigh();
    void setLow();

/*for blink*/
    uint32_t _pattern;
    uint32_t _interval;
    uint16_t _frequency;
    uint32_t _mask = 0x00000001;
    uint32_t _patternBuffer = 0x00000000;
    void maskShift();
};
#endif



