/**версия 0.0.4                     version 0.0.4
создал Александр Ющенко             created by Aleksandr Yuschenko
mailto: asyuschenko@gmail.com
web site: http://allforproject.ru
lib page: http://allforproject.ru/arduino-relay-lib-0-0-4/
2019.09.09
*/
#include "Arduino.h"
#include "Relay.h"
Relay::Relay(){
};
Relay::Relay(uint8_t pin, uint8_t relayProgram){
    _pin=pin;
    _relayProgram=relayProgram;
    pinMode(_pin, OUTPUT);
    setup();
    //_blinkPattern = 0x0ABB9500;
};
Relay::Relay(uint8_t pin, uint8_t relayProgram, uint32_t time){
    _pin=pin;
    _relayProgram=relayProgram;
    _time = time;
    pinMode(_pin, OUTPUT);
    setup();
};
Relay::Relay(uint8_t pin, uint8_t relayProgram, uint32_t pattern, uint32_t interval){
    _pin=pin;
    _relayProgram=relayProgram;
    _pattern = pattern;
    _interval = interval;
    pinMode(_pin, OUTPUT);
    setup();
};
Relay::Relay(uint8_t pin, uint8_t relayProgram, uint32_t pattern, uint32_t interval, uint16_t frequency){
    _pin=pin;
    _relayProgram=relayProgram;
    _pattern = pattern;
    _interval = interval;
    _frequency = frequency;
    pinMode(_pin, OUTPUT);
    setup();
};
void Relay::loop(){
   if (_exec){
        switch (_relayProgram){
            case 0 :
                off();
                _exec = false;
            break;
            case 1 :
                offTime();
                if (state == relayState::OFF_TIME_END) _exec = false;
            break;
            case 2 :
                on();
                _exec = false;
            break;
            case 3 :
                onTime();
                if (state == relayState::ON_TIME_END) _exec = false;
            break;
            case 4 :
                blink();
            break;
            case 5 :
                buzzer();
            break;
            case 6 :
                toggle();
                _exec = false;
            break;

            default:
                /*группа операторов*/;
        }
    };
};
void Relay::stop(){
    _exec = false;
    setup();
}
void Relay::start(){
    _exec = true;
};
void Relay::on(){
    setHigh();
    state = relayState::ON;
};
void Relay::off(){
    setLow();
    state = relayState::OFF;
};
void Relay::onTime(){
    setHigh();
    state = relayState::ON_TIME;
    if (time_delay(_time)){
        setLow();
        state = relayState::ON_TIME_END;
    }
};
void Relay::offTime(){
    setLow();
    state = relayState::OFF_TIME;
    if (time_delay(_time)){
        setHigh();
        state = relayState::OFF_TIME_END;
    }
};
void Relay::blink(){
    if (_patternBuffer){
        if (_pattern & _mask){
            setHigh();
            if (time_delay(_interval)) maskShift();
        }
        else{//if (_pattern & _mask)
            setLow();
            if (time_delay(_interval)) maskShift();
        }
    }
    else { //if (_patternBuffer)
        _patternBuffer = _pattern;
        _mask = 0x00000001;
    }
    state = relayState::BLINK;
};
void Relay::buzzer(){
    if (_patternBuffer){
        if (_pattern & _mask){
            tone(_pin, _frequency);
            if (time_delay(_interval)) maskShift();
        }
        else{//if (_pattern & _mask)
            noTone(_pin);
            if (time_delay(_interval)) maskShift();
            }
    }
    else { //if (_patternBuffer)
        _patternBuffer = _pattern;
        _mask = 0x00000001;
    }
    state = relayState::BUZZER;
};
void Relay::toggle(){
    if (state == relayState::ON) off();
    else on();
}
uint8_t Relay::time_delay(uint32_t time){
    if (timer.getTime() == 0 ) {
            timer.setTime(time);
            timer.reset();
    }
    timer.start();
    timer.delay();
    if (timer.getState() == Timer::timerState::DELAY_OVER){// задержка закончилась
        timer.setTime(0);
        timer.reset();
        return 1;// задержка окончена
    }
    else {
            return 0; // задержка идет
    }

};
void Relay::setup(){
    noTone(_pin);
    if (_relayProgram < 2) {
        on();
    }
    else if  (_relayProgram >= 2){
        off();
    }
    timer.setTime(0);
    timer.reset();
    _mask = 0x00000001;
    _patternBuffer = 0x00000000;
}
void Relay::setHigh(){
    digitalWrite(_pin, HIGH);
    };
void Relay::setLow(){
    digitalWrite(_pin, LOW);
};
void Relay::setPin(uint8_t pin){_pin = pin;};
void Relay::setTime(uint32_t time){_time = time;};
void Relay::setPattern(uint32_t pattern){_pattern = pattern;};
void Relay::setInterval(uint32_t interval){_interval = interval;};
void Relay::setFrequency (uint16_t frequency){_frequency = frequency;};
void Relay::setRelayProgram (uint8_t relayProgram){
    _relayProgram = relayProgram;
    setup();
    };
Relay::relayState Relay::getState(){
    return state;
};
void Relay::maskShift(){
    _patternBuffer = _patternBuffer & (~_mask);
    _mask = _mask << 1;
};

