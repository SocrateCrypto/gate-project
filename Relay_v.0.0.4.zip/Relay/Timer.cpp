/**������ 0.0.2                     version 0.0.2
������ ��������� ������             created by Aleksandr Yuschenko
mailto: asyuschenko@gmail.com
web site: http://allforproject.ru
lib page: http://allforproject.ru/arduino-timer-lib/
2019.01.28
*/
#include "Arduino.h"
#include "Timer.h"

Timer::Timer(){
_delayTime = 0;
state = timerState::DELAY_OVER;
};
Timer::Timer(uint32_t delayTime){
_delayTime = delayTime;
reset();
};
void Timer::delay(){
    if(state == timerState::COUNTDOWN){
        if (millis() < _timeStore){
            if(millis() + 4294967295 - _timeStore >  _delayTimeBuffer) {state = timerState::DELAY_OVER;}
        }
        else{
            if(millis () > _timeStore + _delayTimeBuffer) {state = timerState::DELAY_OVER;}
        }
    }
};
void Timer::start(){
    if ((state == timerState::READY) || (state == timerState::PAUSED)){
        state = timerState::COUNTDOWN;
        _timeStore = millis();
    }
};
void Timer::stop(){
    state = timerState::PAUSED;
    if (millis() < _timeStore){ _delayTimeBuffer = _delayTimeBuffer - (millis() + 4294967295 - _timeStore);}
    else{_delayTimeBuffer = _delayTimeBuffer - (millis() - _timeStore);}
};
void Timer::reset(){
    state = timerState::READY;
    _delayTimeBuffer = _delayTime;
}
void Timer::setTime(uint32_t delayTime){
    _delayTime = delayTime;
    reset();
    };
uint32_t Timer::getTime (){return _delayTime;};

Timer::timerState Timer::getState (){
    return state;
};
